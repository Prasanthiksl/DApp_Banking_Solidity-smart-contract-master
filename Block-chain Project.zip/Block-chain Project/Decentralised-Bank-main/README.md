# Decentralised-Bank

A Decentralised Bank which works on top of Smart Contracts. Users can deposit ether at the bank and get an interest of 10% P.A.
The interest is given in the form of a new cryptocurrency known as "Decentralised Bank Crypto"(DBC). 
Users can withdraw anytime and receive their interests straight into their crypto wallets.
